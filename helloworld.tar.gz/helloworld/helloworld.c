#include <linux/linkage.h>
#include <linux/kernel.h>
asmlinkage int sys_helloworld(void){
	printk( "WELCOME TO THE WORLD OF SWAPNIL!");
	return 1;
};
